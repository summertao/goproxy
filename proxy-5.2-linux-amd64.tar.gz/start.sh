#!/bin/bash
set -e

cd ~
proxy http --daemon --forever -t tcp -p ":33080" -F proxy/auth-file.txt
